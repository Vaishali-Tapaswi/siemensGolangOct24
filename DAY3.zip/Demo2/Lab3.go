package main 
import "fmt"

func main(){
	//Array - Fixed Size 
	primes := [6]int{2, 3, 5, 7, 11, 13}
	fmt.Println(primes)
	// Slice - Dynamic Size 
	sl1 := primes[:]
	fmt.Println(sl1)

	sl2 := primes[0:2]
	fmt.Println(sl2)

	sl2 = primes[2:5]
	sl2[0]= 999
	fmt.Println(sl2)
	fmt.Println("Array " , primes)
	}


