package main 
import "fmt"

func main(){
	sl1 := make([]int,3)
	//sl1 := []int{11,22,33}
	//fmt.Println(sl1)
	fmt.Println(" sl1 length = " , len(sl1), " capacity = ", cap(sl1))
	//func append(s []T, vs ...T) []T
	sl1 = append(sl1, 44)
	fmt.Println(sl1)
	fmt.Println(" sl1 length = " , len(sl1), " capacity = ", cap(sl1))
	sl1 = append(sl1, 55)
	fmt.Println(sl1)
	sl1 = append(sl1, 66)
	fmt.Println(sl1)
	fmt.Println(" sl1 length = " , len(sl1), " capacity = ", cap(sl1))
	sl1 = append(sl1, 77)
	fmt.Println(sl1)
	fmt.Println(" sl1 length = " , len(sl1), " capacity = ", cap(sl1))
	for i, v := range sl1 {
		fmt.Println( i ,"= ", v)
	}
}