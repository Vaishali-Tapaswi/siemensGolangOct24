package main

import (
	"fmt"
	"time"
)

func main(){
	go print("x")
	go print("-")
	go print("o")
	fmt.Println("Done !!")
	//Options -  1. wait for io  2. sleep
/*
	i := 0
	fmt.Println("Enter a number to continue")
	fmt.Scanln(&i)
*/
	time.Sleep(10 * time.Second)
}

func print(str string){
	for i:=0;i<500;i++{
		fmt.Print(str , " ")
	}
}