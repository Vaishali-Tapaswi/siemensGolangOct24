package main

import (
	"fmt"
	"github.com/magiconair/properties"
)

func main(){
	prop := properties.MustLoadFile("demo.properties", properties.UTF8)
	fmt.Println(prop)
	v, ok := prop.Get("host")
	fmt.Println(v, ok)
	v, ok = prop.Get("port")
	fmt.Println(v, ok)
}