package main

import (
	"fmt"
	"time"
	"sync"
)

type Bank struct {
	balance int
}

func closech(ch chan int) {
	if chclose == false {
		chclose = true
		close(ch)
	}
}

var chclose = false

func main() {
	//ch := make(chan int)
	var mutex sync.Mutex	
	bnk := Bank{0}
	ch := make(chan int)

	go bnk.deposit(ch,&mutex)
	go bnk.withdraw(ch,&mutex)
	fmt.Println("After both the goroutines are started ", bnk.balance)
	fmt.Println("Balance = " , <-ch)
	fmt.Println("Balance = " , <-ch)

}

func (b *Bank) deposit(ch chan int, mutex *sync.Mutex) {
	defer closech(ch)
	for i := 1; i <= 100; i++ {
		mutex.Lock()
		bal := b.balance
		bal += 1
		time.Sleep(1 * time.Millisecond)
		b.balance = bal
		mutex.Unlock()
		if i%100 == 0 {
			fmt.Println("balanace after deposit is ", b.balance)
		}
	}
	ch<- b.balance
}

func (b *Bank) withdraw(ch chan int, mutex *sync.Mutex) {
	defer closech(ch)
	for i := 1; i <= 100; i++ {
		mutex.Lock()
		bal := b.balance
		bal -= 1
		// mutex should not have sleep 
		time.Sleep(1 * time.Millisecond)
		b.balance = bal
		mutex.Unlock()
		if i%100 == 0 {

			fmt.Println("balanace after withdraw is ", b.balance)
		}

	}
	ch<- b.balance
}
