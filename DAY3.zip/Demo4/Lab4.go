package main

import (
	"fmt"
	"log"
	"net/http"
)

func main() {
	//http.Handle("/foo", fooHandler)

	http.HandleFunc("/bar", 
	func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, "<h1>Hello World !!</h1>")
		fmt.Fprint(w, "<h1>Method</h1>"+ r.Method)
	})

	log.Fatal(http.ListenAndServe(":8080", nil))
}
