package main

import "testing"

func BenchmarkCalc(b *testing.B) {
    for i:=0;i< b.N;i++ {
        calc(10,50)
    }
}

func TestCalc(t *testing.T){
	gotsum, gotsub := calc(10,50)
	if (gotsum != 60 ){
		t.Errorf("calc(10,50) = %d; want 60", gotsum)
	}
	if (gotsub != -40){
		t.Errorf("calc(10,50) = %d; want -40", gotsub)
	}
}
 
func TestSwap(t *testing.T) {
    got1, got2 := swap("GO", "LANG")
    if got1 != "LANG" {
        t.Errorf("swap('GO', 'LANG') = %s; want LANG", got1)
    }
    if got2 != "GO" {
        t.Errorf("swap('GO', 'LANG') = %s; want GO", got2)
    }
}
 
func TestDivide(t *testing.T) {
    got := divide("10", "2")
    if got != 5 {
        t.Errorf("divide('10', '2') = %d; want 5", got)
    }
}
 
func TestDivideByZero(t *testing.T) {
    defer func() {
        if r := recover(); r == nil {
            t.Errorf("divide('10', '0') did not panic")
        }
    }()
    divide("10", "0")
}
 
func TestCharDivide(t *testing.T) {
    got := divide("A", "2")
    if got != 0 {
        t.Errorf("divide('A', '2') = %d; want 0", got)
    }
}