package main 
import 	(
	"database/sql"
    _ "github.com/go-sql-driver/mysql"
	"fmt"
)



func main(){
//admin:MyPassword@tcp(database-1.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/dbname
	constr :="admin:MyPassword@tcp(database-1.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/mydb"
	db, err := sql.Open("mysql", constr)
	defer db.Close()
	fmt.Println("Err = ", err)
	fmt.Println("Db =", db)
	// create table dept (deptno numeric primary key, dname varchar(20), loc varchar(20))
	insertsql := "insert into dept values (20, 'Fin','Hyd')"
	result, err := db.Exec(insertsql)
	fmt.Println("Insert Err = ", err)
	rsaff, err := result.RowsAffected() 
	fmt.Println("result =", rsaff)

}