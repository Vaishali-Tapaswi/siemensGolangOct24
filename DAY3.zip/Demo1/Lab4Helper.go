package main
func calc(no1, no2 int )(sum, sub int){
	sum, sub = no1+no2, no1-no2
	return 
}