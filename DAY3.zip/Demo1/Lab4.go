package main
import (
	"fmt"
)

func main() {
	fmt.Println("Hello World !!")
	sum, sub := calc(100,50)
	fmt.Println("Sum = ", sum, ", Sub = ", sub)	
}
