package main
import (
	"fmt"
)
func increment(ptoint *int ){
	fmt.Println("in increment with no = "  , ptoint)
	*ptoint = *ptoint + 1
	fmt.Println("in increment changed number to  = "  , ptoint)
}
func main() {
	no := 200
	fmt.Println("No  = ", no)
	increment(&no)
	fmt.Println("No  = ", no)	
}
