package main

import (
	"fmt"
	"sort"
)

func printFibseries(num int) {
	a, b := 0, 1
	c := a + b
	fmt.Printf(" Series is: %d %d", a, b)
	for b <= num {
		fmt.Printf(" %d", b)
		c = b
		b = a + b
		a = c
		}
}
func main() {
	var val1 int
	fmt.Println("Enter a number : ")
	fmt.Scanln(&val1)
	printFibseries(val1)

    var inputStrings [5]string;
    for i := 0; i < 5; i++{
        fmt.Println("Enter a string " , i , " : ")
        num, _ := fmt.Scanln(&inputStrings[i])
        if num < 1 {
            fmt.Println("Please enter a valid string")
        }
    }

	fmt.Println("Array Content = " , inputStrings)
//	inputStrings.sort -> receiver methods 
	sort.Strings(inputStrings[:])
	fmt.Println("after sort Array Content = " , inputStrings)
}

