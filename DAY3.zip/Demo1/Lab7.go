package main 

import "fmt"

func main(){
	defer fmt.Println("Hello ")
	add()
	fmt.Println("World ")
}

func add(){
	defer fmt.Println("in add function - defer ")
	for i := 0; i < 5; i++{
		defer fmt.Println("add defer " ,  i)
	}
	fmt.Println("in function add line1 ")
}