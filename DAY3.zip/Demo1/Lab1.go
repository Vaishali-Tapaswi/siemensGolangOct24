package main
import (
	"fmt"
	"os"
)
func main() {
	fmt.Println("Hello World !!")
	hname, err := os.Hostname()
	fmt.Println(hname, err)
}
