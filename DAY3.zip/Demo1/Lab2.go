package main

import "fmt"

func swap(s1,s2 string)(string, string) {
	return s2, s1;
}
func calc(no1, no2 int )(int, int){
	return no1+no2, no1-no2
}
func main() {
	fmt.Println("Hello World !!")
	sum, sub := calc(100,50)
	fmt.Println("Sum = ", sum, ", Sub = ", sub)	
	s1, s2 := "abc", "xyz"
	fmt.Println("s1 =", s1 , ", s2 = " , s2)
	ss1, ss2 := swap(s1 , s2)
	fmt.Println("ss1 =", ss1 , ", ss2 = " , ss2)

}
