package main
import (
	"fmt"
	"os"
	"strconv"
)

func main(){
	strarr := os.Args
	fmt.Println(strarr)
	cnt := len(os.Args)
	fmt.Println("Length = " , cnt)
	if cnt <= 1 {
		fmt.Println("No additional Arguments ")
	} else {
		fmt.Println("Additional Arguments ")
	}
	sum := 0
	for i := 1; i < cnt; i++ {
		no, err := strconv.Atoi(strarr[i])
		fmt.Println("no = ", no , " err = ", err)
		if err != nil {
			fmt.Println(" err is not nil ")
			break
		}
		sum += no
	}
	fmt.Println(sum)
	

}