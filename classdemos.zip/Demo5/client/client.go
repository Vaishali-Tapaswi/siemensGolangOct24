package main

import (
	"fmt"
	"tempcom/calc"
)

func main() {
	no1, no2 := 100, 30
	res := calc.Add(no1, no2)
	fmt.Println("Result of add = ", res)
	res = calc.Divide(no1, no2)
	fmt.Println("Result of Divide = ", res)
}
