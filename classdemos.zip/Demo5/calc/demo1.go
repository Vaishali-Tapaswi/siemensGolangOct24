package calc

import (
	"fmt"
)

func Add(no1, no2 int) int {
	fmt.Println("Calc add invoked with ", no1, no2)
	return no1 + no2
}
func Divide(no1, no2 int) int {
	fmt.Println("Calc divide invoked with ", no1, no2)
	return no1 / no2
}
