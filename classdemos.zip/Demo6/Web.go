package main

import (
	"example.com/dblib"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

func myhandlefunc(w http.ResponseWriter, r *http.Request) {
	mgr := dblib.EmpMgr{}
	switch method := r.Method; method {
	case "GET":
		if employees, err := mgr.List(); err != nil {
			fmt.Println(err)
		} else {
			barr, _ := json.Marshal(employees)
			w.Write(barr)
		}
	case "POST":
		fmt.Fprint(w, "<h1>Post Method</h1>"+r.Method)
		emp := dblib.Emp{}
		err := json.NewDecoder(r.Body).Decode(&emp)
		fmt.Println("err", err)
		fmt.Println("in post ", emp)
		if err := mgr.Create(emp); err != nil {
			fmt.Println(err)
		}
		fmt.Fprint(w, "<h1>Inserted </h1>")
	}
}
func main() {

	http.HandleFunc("/dept", myhandlefunc)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
