package dblib

type Emp struct {
	EmpNo  int     `json:"empno"`
	EName  string  `json:"ename"`
	Salary float64 `json:"salary"`
}

type EmpMgr struct {
}
