package main

import "strconv"
import "fmt"
func divide(s1, s2 string) int {
	no1,_:=strconv.Atoi(s1)
	no2,_:=strconv.Atoi(s2)
	return no1/no2
}
func swap(s1,s2 string)(string, string) {
	return s2, s1;
}
func calc(no1, no2 int )(int, int){
	return no1+no2, no1-no2
}
func main() {
	fmt.Println(divide("100","20"))
	//fmt.Println(divide("100","0"))
	fmt.Println(divide("A","10"))


}
