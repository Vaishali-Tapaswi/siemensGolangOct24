package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)

type Emp struct {
	EmpNo  int
	EName  string
	Salary float64
}

type EmpMgr struct {
}

func GetDBConnection() *sql.DB {
	dsn := "admin:MyPassword@tcp(database-1.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/mydb"
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		panic("Problem in getting database connection")
	}
	return db
}

func (mgr *EmpMgr) create(emp Emp) error {
	dbConnection := GetDBConnection()
	defer dbConnection.Close()
	query := "INSERT INTO Emp (empno, ename, salary) VALUES (?, ?, ?)"
	_, err := dbConnection.Exec(query, emp.EmpNo, emp.EName, emp.Salary)
	return err
}

func (mgr *EmpMgr) list() ([]Emp, error) {
	dbConnection := GetDBConnection()
	defer dbConnection.Close()
	query := "SELECT * FROM Emp"
	rows, err := dbConnection.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var employees []Emp
	for rows.Next() {
		var emp Emp
		rows.Scan(&emp.EmpNo, &emp.EName, &emp.Salary)
		employees = append(employees, emp)
	}
	return employees, nil
}

func main() {
	mgr := EmpMgr{}

	// Example usage
	/*
	   newEmp := Emp{EmpNo: 3, EName: "SKY", Salary: 50000}
	   if err := mgr.create(newEmp); err != nil {
	       fmt.Println(err)
	   }
	*/
	
	if employees, err := mgr.list(); err != nil {
		fmt.Println(err)
	} else {
		for _, emp := range employees {
			fmt.Printf("EmpNo: %d, EName: %s, Salary: %.2f\n", emp.EmpNo, emp.EName, emp.Salary)
		}
	}
}
