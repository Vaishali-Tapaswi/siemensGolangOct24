package main

import (
	"database/sql"

	_ "github.com/go-sql-driver/mysql"
)

type Emp struct {
	EmpNo  int     `json:"empno"`
	EName  string  `json:"ename"`
	Salary float64 `json:"salary"`
}

type EmpMgr struct {
}

func GetDBConnection() *sql.DB {
	dsn := "admin:MyPassword@tcp(database-1.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/mydb"
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		panic("Problem in getting database connection")
	}
	return db
}

func (mgr *EmpMgr) create(emp Emp) error {
	dbConnection := GetDBConnection()
	defer dbConnection.Close()
	query := "INSERT INTO Emp (empno, ename, salary) VALUES (?, ?, ?)"
	_, err := dbConnection.Exec(query, emp.EmpNo, emp.EName, emp.Salary)
	return err
}

func (mgr *EmpMgr) list() ([]Emp, error) {
	dbConnection := GetDBConnection()
	defer dbConnection.Close()
	query := "SELECT * FROM Emp"
	rows, err := dbConnection.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var employees []Emp
	for rows.Next() {
		var emp Emp
		rows.Scan(&emp.EmpNo, &emp.EName, &emp.Salary)
		employees = append(employees, emp)
	}
	return employees, nil
}
