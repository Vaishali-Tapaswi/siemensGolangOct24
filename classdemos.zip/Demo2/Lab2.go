package main 
import "fmt"
type Emp struct {
	Empno int
	Ename string
	Salary float32
}
func main(){
	var emparr [3]Emp
	
	for i:=0;i<len(emparr);i++{
		emp := Emp{}
		fmt.Println("EMp = " , emp)
		fmt.Println("Enter Employee details ")
		fmt.Scanf("%d%s%f\n", &emp.Empno, &emp.Ename, &emp.Salary)
		fmt.Println("EMp = " , emp)
		emparr[i] = emp
	}
	fmt.Println(emparr)
}
