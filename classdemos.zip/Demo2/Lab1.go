package main 
import "fmt"
type Vertex struct {
	X int
	Y int
}

func main(){
	var v1 Vertex 
	v1 = Vertex{10,10}
	v2 := Vertex{40,50}
	fmt.Println("v1 = ", v1)
	fmt.Println("v2 = ", v2)
	v1 = Vertex{}
	v2 = Vertex{Y :111}
	fmt.Println("v1 = ", v1)
	fmt.Println("v2 = ", v2)
	
}