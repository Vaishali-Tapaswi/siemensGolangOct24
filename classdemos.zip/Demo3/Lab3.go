package main
import (
	"fmt"
	"net/http"
	"io"
	"log"
)
func main(){
	//
	resp, err := http.Get("https://reqres.in/api/users/20")
	fmt.Println(resp, "\n", err)
	fmt.Println("Status = " , resp.Status , resp.StatusCode)
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("body content = " , string(b))
}