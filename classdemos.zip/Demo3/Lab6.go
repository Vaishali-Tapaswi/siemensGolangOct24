package main

import (
	"fmt"
//	"time"
)

func main(){
	ch := make(chan int)
	go print("x", ch)

	fmt.Println("waiting for some input on channel ")
	for percent:= range ch {
			fmt.Println(".. input received on channel ", percent)
		}
}

func print(str string,ch chan int){
	defer close(ch)	
	for i:=1;i<=500;i++{
		fmt.Print(str , " ")
		if i % 100 == 0 {
			fmt.Println("\n", str , " is ", i / 5 , " % done !!")
			ch <- i/5
		}
	}
	
}
