package main

import (
	"fmt"
	"encoding/json"
	"os"
	"log"
)
type Emp struct {
	Id     int `json:"empno"`
	Name   string `json:"ename"`
	Salary float32 `json:"salary"`
}

func main(){
	emp:= Emp{10,"AAA",111.11}
	barr, err := json.Marshal(emp)
	fmt.Println("barr=", string(barr), "err = ", err)
	data, err := os.ReadFile("emp.txt")
	if err != nil {
		log.Fatal(err)
	}
	e1 := Emp{}
	err = json.Unmarshal(data, &e1)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Emp = " , e1)
}